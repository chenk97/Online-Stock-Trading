package model;

import java.util.Date;

public class Account {
    private int accountId;
    private Date creationDate;
}
