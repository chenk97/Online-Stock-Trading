# On-line Stock Trading
<br>Author:
<br>Jiarong Chen  jiarchen@cs.stonybrook.edu
<br>Sherry Lyu  xilyu@cs.stonybrook.edu

## Information:
Database: jdbc:mysql://mysql4.cs.stonybrook.edu:3306/jiarchen
<br>  Username: jiarchen
<br>  Password: Cjr19971117

## Three Users for Test
 `Manager`  Email: chen@g.com Password: 123456
 <br>`Customer Representative`  Email: employee@gmail.com Password: 123456
 <br>`Customer` Email: jiar@gmail.com Password: 123456

 ## Files
.war file: `sample.war`  
data dump: `dump.sql`
<br>.zip file: `CSE-305 PROJ.zip`
